# Not a pypack

This is an example package. See [here](https://packaging.python.org/tutorials/packaging-projects/) for the tutorial on creating and uploading a package.


